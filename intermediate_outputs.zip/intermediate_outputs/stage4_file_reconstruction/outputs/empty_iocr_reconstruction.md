# Document Reconstruction

**Generated on:** 2025-09-24T17:31:06.316071
**Total elements:** 2
**Total text blocks:** 51

## Section 1

| Column 1 | Column 2 | Column 3 | Column 4 | Column 5 |
| --- | --- | --- | --- | --- |
| R0C0 | R0C1 | December 31, %of December31, % of 2007 Total 2006 Total | R0C3 | R0C4 |
| R1C0 | R1C1 | (n thousands, except percentages) | R1C3 | R1C4 |
| R2C0 | Receivables outstanding ......................... $4,157,287 100% $4,171,262 100% | R2C2 | R2C3 | R2C4 |
| Receivables balances contractually delinquent: | R3C1 | R3C2 | R3C3 | R3C4 |
| R4C0 | B31 to 60 days ...... 2... eee eee eee 70,512 1.7% 62,221 15% | R4C2 | R4C3 | R4C4 |
| R5C0 | 61 to 90 days .... 2.2 eee eee eee 48,755 12 40,929 1.0 | R5C2 | R5C3 | R5C4 |
| R6C0 | 91 or more days ...... 02.2.0 101,928 2.4 88,078 2.1 | R6C2 | R6C3 | R6C4 |
| R7C0 | Total. 2.2... eee eee eee eee eee © § 221,195 5.3% $ 191,228 4.6% | R7C2 | R7C3 | R7C4 |

| Column 1 | Column 2 | Column 3 | Column 4 |
| --- | --- | --- | --- |
| R0C0 | Year Ended December 31, | R0C2 | R0C3 |
| R1C0 | 2007 2006 2005 | R1C2 | R1C3 |
| R2C0 | (n thousands, except percentages) | R2C2 | R2C3 |
| Average managed receivables ....................... $3,909,627 $3,640,057 $3,170,485 | R3C1 | R3C2 | R3C3 |
| Net charge-offs ........ 2.22020 ccc e eee e eee eee 227,393 180,449 207,397 | R4C1 | R4C2 | R4C3 |
| Net charge-offs as a percentage of average managed receivables ..... 0.0.00... cece eee eee es | R5C1 | 5.8% 5.0% 6.5% | R5C3 |

