# Document Reconstruction

**Generated on:** 2025-09-24T17:32:15.286538
**Total elements:** 1
**Total text blocks:** 20

## Section 1

| Column 1 | Column 2 | Column 3 | Column 4 | Column 5 | Column 6 | Column 7 |
| --- | --- | --- | --- | --- | --- | --- |
| R0C0 | December 31, 2013 | R0C2 | R0C3 | December 31, 2012 | R0C5 | R0C6 |
| R1C0 | R1C1 | R1C2 | R1C3 | R1C4 | R1C5 | R1C6 |
| R2C0 | R2C1 | R2C2 | R2C3 | R2C4 | R2C5 | R2C6 |
| R3C0 | R3C1 | R3C2 | R3C3 | R3C4 | R3C5 | R3C6 |
| R4C0 | R4C1 | Owned Optioned Controlled Owned Optioned Controlled Northeast 7,423 2,762 10,185 9,211 2,655 11,866 Southeast 12,702 4,296 16,998 13,372 2,756 16,128 Florida 21,805 6,956 28,761 23,906 3,689 27,595 Texas 12,038 3,860 15,898 12,218 3,685 15,903 North 11,785 7,952 19,737 12,946 2,603 15,549 Southwest 29,459 2,440 31,899 31,407 1,427 32,834 Total 95,212 28,266 123,478 103,060 16,815 119,875 | R4C3 | R4C4 | R4C5 | R4C6 |
| R5C0 | R5C1 | R5C2 | R5C3 | R5C4 | R5C5 | R5C6 |
| R6C0 | R6C1 | R6C2 | R6C3 | R6C4 | R6C5 | R6C6 |
| R7C0 | R7C1 | R7C2 | R7C3 | R7C4 | R7C5 | R7C6 |
| R8C0 | R8C1 | R8C2 | R8C3 | R8C4 | R8C5 | R8C6 |
| Developed (%) | 24% | 18% 23% | 27% | R9C4 | 34% | 28% |

